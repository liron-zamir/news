-- Migration number: 0001        2025-04-07T11:45:00.000Z
DROP TABLE IF EXISTS news_sources;
DROP TABLE IF EXISTS headlines;
DROP TABLE IF EXISTS articles;
DROP TABLE IF EXISTS writers;
DROP TABLE IF EXISTS access_logs;

-- News sources table
CREATE TABLE IF NOT EXISTS news_sources (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE NOT NULL,
  url TEXT NOT NULL,
  language TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Headlines table
CREATE TABLE IF NOT EXISTS headlines (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  url TEXT NOT NULL,
  published_at DATETIME,
  collected_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (source_id) REFERENCES news_sources(id)
);

-- Writers table
CREATE TABLE IF NOT EXISTS writers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE NOT NULL,
  source_id INTEGER NOT NULL,
  is_top_writer BOOLEAN NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (source_id) REFERENCES news_sources(id)
);

-- Articles table
CREATE TABLE IF NOT EXISTS articles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_id INTEGER NOT NULL,
  writer_id INTEGER,
  title TEXT NOT NULL,
  url TEXT NOT NULL,
  published_at DATETIME,
  collected_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (source_id) REFERENCES news_sources(id),
  FOREIGN KEY (writer_id) REFERENCES writers(id)
);

-- Access logs table
CREATE TABLE IF NOT EXISTS access_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ip TEXT,
  path TEXT,
  accessed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Initial data for news sources
INSERT INTO news_sources (name, url, language) VALUES 
  ('Ynet', 'https://www.ynet.co.il/', 'hebrew'),
  ('Haaretz', 'https://www.haaretz.com/', 'english'),
  ('Jerusalem Post', 'https://www.jpost.com/', 'english'),
  ('Israel Hayom', 'https://www.israelhayom.com/', 'english'),
  ('Walla', 'https://www.walla.co.il/', 'hebrew');

-- Initial data for top writers
INSERT INTO writers (name, source_id, is_top_writer) VALUES 
  ('Nahum Barnea', 1, 1),
  ('Ephraim Shoham-Steiner', 2, 1),
  ('Dmitry Shumsky', 2, 1),
  ('Yagil Levy', 2, 1),
  ('Ari Shavit', 2, 1),
  ('Yaakov Katz', 3, 1),
  ('Miri Weissman', 4, 1),
  ('Ariel Kahana', 4, 1),
  ('Shachar Kleiman', 4, 1),
  ('Erez Linn', 4, 1);

-- Create indexes
CREATE INDEX idx_headlines_source_id ON headlines(source_id);
CREATE INDEX idx_headlines_collected_at ON headlines(collected_at);
CREATE INDEX idx_articles_source_id ON articles(source_id);
CREATE INDEX idx_articles_writer_id ON articles(writer_id);
CREATE INDEX idx_articles_collected_at ON articles(collected_at);
CREATE INDEX idx_access_logs_accessed_at ON access_logs(accessed_at);
