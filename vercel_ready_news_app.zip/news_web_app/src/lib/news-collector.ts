/**
 * News Collector Library
 * 
 * This module provides functions to collect news headlines and articles
 * from major Israeli news websites.
 */

import { load } from 'cheerio';
import { sql } from '@vercel/postgres';

// News website configuration
export const NEWS_WEBSITES = [
  {
    name: "Ynet",
    url: "https://www.ynet.co.il/",
    language: "hebrew",
    headlineSelector: "div.slotTitle",
    writerSelectors: ["span.writer"],
    articleLinkSelector: "a.slotTitle",
  },
  {
    name: "Haaretz",
    url: "https://www.haaretz.com/",
    language: "english",
    headlineSelector: "h1, h2, h3",
    writerSelectors: ["a.c-articleAuthors-link", "div.c-articleAuthors-name"],
    articleLinkSelector: "a.c-teaser-link",
  },
  {
    name: "Jerusalem Post",
    url: "https://www.jpost.com/",
    language: "english",
    headlineSelector: "h1, h2, h3",
    writerSelectors: ["div.author-name", "span.author"],
    articleLinkSelector: "a.article-link",
  },
  {
    name: "Israel Hayom",
    url: "https://www.israelhayom.com/",
    language: "english",
    headlineSelector: "h1, h2, h3",
    writerSelectors: ["div.author", "span.author-name"],
    articleLinkSelector: "a.article-link",
  },
  {
    name: "Walla",
    url: "https://www.walla.co.il/",
    language: "hebrew",
    headlineSelector: "h1, h2, h3",
    writerSelectors: ["div.author", "span.writer"],
    articleLinkSelector: "a.article-link",
  }
];

/**
 * Fetch a webpage with error handling
 */
export async function fetchPage(url: string): Promise<string | null> {
  try {
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
      },
      cf: {
        cacheTtl: 3600, // Cache for 1 hour
        cacheEverything: true,
      },
    });
    
    if (!response.ok) {
      console.error(`Failed to fetch ${url}: ${response.status} ${response.statusText}`);
      return null;
    }
    
    return await response.text();
  } catch (error) {
    console.error(`Error fetching ${url}:`, error);
    return null;
  }
}

/**
 * Extract headlines from a news website
 */
export async function extractHeadlines(website: typeof NEWS_WEBSITES[0], ): Promise<number> {
  console.log(`Extracting headlines from ${website.name}`);
  const html = await fetchPage(website.url);
  if (!html) {
    return 0;
  }
  
  const $ = load(html);
  let count = 0;
  
  // Get source ID
  const sourceResult = await sql`
    "SELECT id FROM news_sources WHERE name = ?"
  `.then(result => result.rows[0]);
  
  if (!sourceResult) {
    console.error(`Source ${website.name} not found in database`);
    return 0;
  }
  
  const sourceId = sourceResult.id;
  
  // Extract headlines
  $(website.headlineSelector).each(async (_, element) => {
    const headlineText = $(element).text().trim();
    if (!headlineText) return;
    
    // Find the associated link
    let link: string | null = null;
    
    if ($(element).is('a')) {
      link = $(element).attr('href') || null;
    } else if ($(element).parent().is('a')) {
      link = $(element).parent().attr('href') || null;
    } else {
      const linkElement = $(element).find('a').first() || $(element).parent().find('a').first();
      if (linkElement.length) {
        link = $(linkElement).attr('href') || null;
      }
    }
    
    // Make sure the link is absolute
    if (link && !link.startsWith('http')) {
      link = new URL(link, website.url).toString();
    }
    
    if (headlineText && link) {
      try {
        // Check if headline already exists
        const existingHeadline = await sql`
          "SELECT id FROM headlines WHERE source_id = ? AND url = ?"
        `.then(result => result.rows[0]);
  
  if (!sourceResult) {
    console.error(`Source ${website.name} not found in database`);
    return null;
  }
  
  const sourceId = sourceResult.id;
  
  // Check each writer selector
  for (const selector of website.writerSelectors) {
    const writerElements = $(selector);
    
    for (let i = 0; i < writerElements.length; i++) {
      const writerName = $(writerElements[i]).text().trim();
      
      if (writerName) {
        // Check if this is a top writer
        const writerResult = await sql`
          "SELECT id FROM writers WHERE source_id = ? AND name LIKE ? AND is_top_writer = 1"
        `.then(result => result.rows[0]);
        
        if (writerResult) {
          return writerResult.id;
        }
      }
    }
  }
  
  return null;
}

/**
 * Extract articles by top writers
 */
export async function extractArticlesByTopWriters(
  website: typeof NEWS_WEBSITES[0], 
  
): Promise<number> {
  console.log(`Looking for articles by top writers on ${website.name}`);
  const html = await fetchPage(website.url);
  if (!html) {
    return 0;
  }
  
  const $ = load(html);
  let count = 0;
  
  // Get source ID
  const sourceResult = await sql`
    "SELECT id FROM news_sources WHERE name = ?"
  `.then(result => result.rows[0]);
  
  if (!sourceResult) {
    console.error(`Source ${website.name} not found in database`);
    return 0;
  }
  
  const sourceId = sourceResult.id;
  
  // Find all article links
  const articleLinks: string[] = [];
  $(website.articleLinkSelector).each((_, element) => {
    const href = $(element).attr('href');
    if (href) {
      // Make sure the link is absolute
      const fullUrl = href.startsWith('http') 
        ? href 
        : new URL(href, website.url).toString();
      
      articleLinks.push(fullUrl);
    }
  });
  
  // Check each article (limit to first 10 to avoid too many requests)
  const limitedLinks = articleLinks.slice(0, 10);
  
  for (const link of limitedLinks) {
    const writerId = await isArticleByTopWriter(link, website, db);
    
    if (writerId) {
      // Get article title
      const articleHtml = await fetchPage(link);
      if (articleHtml) {
        const article$ = load(articleHtml);
        const titleElement = article$('h1').first();
        const title = titleElement.length 
          ? titleElement.text().trim() 
          : "Untitled Article";
        
        try {
          // Check if article already exists
          const existingArticle = await sql`
            "SELECT id FROM articles WHERE source_id = ? AND url = ?"
          `.then(result => result.rows);
  
  return headlines.results;
}

/**
 * Get recent articles by top writers from database
 */
export async function getRecentArticlesByTopWriters(, limit = 20): Promise<any[]> {
  const articles = await sql``
    SELECT a.id, a.title, a.url, a.published_at, a.collected_at, 
           s.name as source, s.language, w.name as writer
    FROM articles a
    JOIN news_sources s ON a.source_id = s.id
    JOIN writers w ON a.writer_id = w.id
    WHERE w.is_top_writer = 1
    ORDER BY a.collected_at DESC
    LIMIT ?
  ``.then(result => result.rows);
  
  return articles.results;
}

/**
 * Get headlines by source
 */
export async function getHeadlinesBySource(, sourceName: string, limit = 20): Promise<any[]> {
  const headlines = await sql``
    SELECT h.id, h.title, h.url, h.published_at, h.collected_at, s.name as source, s.language
    FROM headlines h
    JOIN news_sources s ON h.source_id = s.id
    WHERE s.name = ?
    ORDER BY h.collected_at DESC
    LIMIT ?
  ``.then(result => result.rows);
  
  return headlines.results;
}

/**
 * Get articles by writer
 */
export async function getArticlesByWriter(, writerName: string, limit = 20): Promise<any[]> {
  const articles = await sql``
    SELECT a.id, a.title, a.url, a.published_at, a.collected_at, 
           s.name as source, s.language, w.name as writer
    FROM articles a
    JOIN news_sources s ON a.source_id = s.id
    JOIN writers w ON a.writer_id = w.id
    WHERE w.name LIKE ?
    ORDER BY a.collected_at DESC
    LIMIT ?
  ``.then(result => result.rows);
  
  return articles.results;
}

/**
 * Log access to the application
 */
export async function logAccess(, ip: string, path: string): Promise<void> {
  try {
    await sql`
      "INSERT INTO access_logs (ip, path, accessed_at) VALUES (?, ?, ?)"
    `;
  } catch (error) {
    console.error(`Error logging access: ${error}`);
  }
}
