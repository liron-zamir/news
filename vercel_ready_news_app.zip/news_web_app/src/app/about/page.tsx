export default function About() {
  return (
    <main className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">About Israeli News Collector</h1>
        
        <div className="mb-6">
          <a href="/" className="text-blue-600 hover:text-blue-800">
            ← Back to home
          </a>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-2xl font-semibold mb-4">Project Overview</h2>
          <p className="mb-4">
            The Israeli News Collector is a web application that automatically collects headlines from major Israeli news websites and articles by top writers. 
            It provides a centralized platform for accessing the latest news from Israel in both Hebrew and English.
          </p>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">News Sources</h2>
          <p className="mb-4">
            We collect news from the following major Israeli news websites:
          </p>
          <ul className="list-disc pl-6 mb-6 space-y-2">
            <li><strong>Ynet</strong> - One of Israel's largest news websites, the online version of Yedioth Ahronoth newspaper (Hebrew)</li>
            <li><strong>Haaretz</strong> - One of Israel's oldest and most prestigious newspapers (English and Hebrew)</li>
            <li><strong>Jerusalem Post</strong> - Israel's most-read English news website</li>
            <li><strong>Israel Hayom</strong> - Israel's most widely read newspaper (English)</li>
            <li><strong>Walla</strong> - One of Israel's leading web portals and news sites (Hebrew)</li>
          </ul>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Top Writers</h2>
          <p className="mb-4">
            We track articles from prominent Israeli journalists and writers, including:
          </p>
          <ul className="list-disc pl-6 mb-6 space-y-2">
            <li><strong>Nahum Barnea</strong> - Senior political columnist at Yedioth Ahronoth</li>
            <li><strong>Ephraim Shoham-Steiner</strong>, <strong>Dmitry Shumsky</strong>, <strong>Yagil Levy</strong>, and <strong>Ari Shavit</strong> - Opinion writers at Haaretz</li>
            <li><strong>Yaakov Katz</strong> - Former editor-in-chief of The Jerusalem Post</li>
            <li><strong>Miri Weissman</strong>, <strong>Ariel Kahana</strong>, <strong>Shachar Kleiman</strong>, and <strong>Erez Linn</strong> - Writers at Israel Hayom</li>
          </ul>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">How It Works</h2>
          <p className="mb-4">
            The application uses web scraping techniques to collect headlines and articles from the news websites. 
            The data is stored in a database and made available through a user-friendly interface.
          </p>
          <p className="mb-4">
            The news collection process runs regularly to ensure you have access to the latest news.
          </p>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Technology Stack</h2>
          <p className="mb-4">
            This application is built using:
          </p>
          <ul className="list-disc pl-6 mb-6 space-y-2">
            <li><strong>Next.js</strong> - React framework for building the web application</li>
            <li><strong>Cloudflare Workers</strong> - For serverless deployment and edge computing</li>
            <li><strong>D1 Database</strong> - Cloudflare's SQL database for storing news data</li>
            <li><strong>Tailwind CSS</strong> - For styling the user interface</li>
          </ul>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">Contact</h2>
          <p className="mb-4">
            For any questions or feedback about this project, please contact us.
          </p>
        </div>
      </div>
    </main>
  );
}
