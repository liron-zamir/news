import { getRecentHeadlines, getRecentArticlesByTopWriters, collectAllNews, logAccess } from '@/lib/news-collector';

export const dynamic = 'force-dynamic';

export default async function Admin() {
  // This is a client-side only component, so we'll handle data fetching in useEffect
  return (
    <main className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Admin Dashboard</h1>
        
        <div className="mb-6">
          <a href="/" className="text-blue-600 hover:text-blue-800">
            ← Back to home
          </a>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md mb-8">
          <h2 className="text-2xl font-semibold mb-4">Collect News</h2>
          <p className="mb-4">
            Manually trigger the news collection process to fetch the latest headlines and articles.
          </p>
          <button 
            id="collectButton"
            className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded"
            onClick={() => {
              const button = document.getElementById('collectButton');
              const status = document.getElementById('collectStatus');
              
              if (button && status) {
                button.textContent = 'Collecting...';
                button.disabled = true;
                status.textContent = 'Collection in progress...';
                
                fetch('/api/collect', {
                  method: 'POST',
                })
                .then(response => response.json())
                .then(data => {
                  if (data.success) {
                    status.textContent = `Success! ${data.message}`;
                  } else {
                    status.textContent = `Error: ${data.error}`;
                  }
                })
                .catch(error => {
                  status.textContent = `Error: ${error.message}`;
                })
                .finally(() => {
                  button.textContent = 'Collect News';
                  button.disabled = false;
                });
              }
            }}
          >
            Collect News
          </button>
          <div id="collectStatus" className="mt-4 text-sm"></div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-2xl font-semibold mb-4">Collection Schedule</h2>
          <p className="mb-4">
            The news collection process runs automatically according to the following schedule:
          </p>
          <ul className="list-disc pl-6 mb-6 space-y-2">
            <li>Every day at 7:00 AM Israel time (Sunday through Thursday)</li>
            <li>Headlines are collected from all configured news sources</li>
            <li>Articles by top writers are identified and collected</li>
          </ul>
          <p className="text-sm text-gray-500">
            Note: The actual schedule depends on the Cloudflare Workers cron trigger configuration.
          </p>
        </div>
      </div>
      
      <script dangerouslySetInnerHTML={{
        __html: `
          document.addEventListener('DOMContentLoaded', function() {
            const collectButton = document.getElementById('collectButton');
            const collectStatus = document.getElementById('collectStatus');
            
            if (collectButton) {
              collectButton.addEventListener('click', function() {
                collectButton.textContent = 'Collecting...';
                collectButton.disabled = true;
                collectStatus.textContent = 'Collection in progress...';
                
                fetch('/api/collect', {
                  method: 'POST',
                })
                .then(response => response.json())
                .then(data => {
                  if (data.success) {
                    collectStatus.textContent = \`Success! \${data.message}\`;
                  } else {
                    collectStatus.textContent = \`Error: \${data.error}\`;
                  }
                })
                .catch(error => {
                  collectStatus.textContent = \`Error: \${error.message}\`;
                })
                .finally(() => {
                  collectButton.textContent = 'Collect News';
                  collectButton.disabled = false;
                });
              });
            }
          });
        `
      }} />
    </main>
  );
}
