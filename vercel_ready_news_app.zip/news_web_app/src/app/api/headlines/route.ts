import { NextRequest } from 'next/server';
import { getRecentHeadlines, logAccess } from '@/lib/news-collector';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    // Get the database binding
    // Using Vercel Postgres directly in the functions
    
    
    
    // Log access
    const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
    const path = request.nextUrl.pathname;
    await logAccess(ip, path);
    
    // Get limit from query params, default to 20
    const url = new URL(request.url);
    const limitParam = url.searchParams.get('limit');
    const limit = limitParam ? parseInt(limitParam, 10) : 20;
    
    // Get recent headlines
    const headlines = await getRecentHeadlines(limit);
    
    return Response.json({
      success: true,
      count: headlines.length,
      data: headlines
    });
  } catch (error) {
    console.error('Error fetching headlines:', error);
    return Response.json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }, { status: 500 });
  }
}
