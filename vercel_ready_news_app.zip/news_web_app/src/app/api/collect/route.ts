import { NextRequest } from 'next/server';
import { collectAllNews } from '@/lib/news-collector';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    // Get the database binding
    // Using Vercel Postgres directly in the functions
    
    
    
    // Collect news from all websites
    const result = await collectAllNews(db);
    
    return Response.json({
      success: true,
      message: `Collected ${result.headlines} headlines and ${result.articles} articles`,
      data: result
    });
  } catch (error) {
    console.error('Error collecting news:', error);
    return Response.json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }, { status: 500 });
  }
}
