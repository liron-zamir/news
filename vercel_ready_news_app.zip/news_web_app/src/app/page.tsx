import { getRecentHeadlines } from '@/lib/news-collector';

export const dynamic = 'force-dynamic';

export default async function Home({ searchParams }: { searchParams: { [key: string]: string | string[] | undefined } }) {
  // Get the database binding
  // Using Vercel Postgres directly in the functions
  
  // Fetch recent headlines
  let headlines = [];
  let error = null;
  
  try {
    if (db) {
      headlines = await getRecentHeadlines(10);
    } else {
      error = "Database not available";
    }
  } catch (e) {
    error = e instanceof Error ? e.message : "Unknown error";
  }
  
  return (
    <main className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-center mb-8">Israeli News Collector</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-2xl font-semibold mb-4">Latest Headlines</h2>
            {error ? (
              <div className="text-red-500">{error}</div>
            ) : headlines.length > 0 ? (
              <ul className="space-y-4">
                {headlines.map((headline: any) => (
                  <li key={headline.id} className="border-b pb-3">
                    <a 
                      href={headline.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:text-blue-800 font-medium"
                    >
                      {headline.title}
                    </a>
                    <div className="text-sm text-gray-500 mt-1">
                      Source: {headline.source} | 
                      Language: {headline.language} | 
                      Collected: {new Date(headline.collected_at).toLocaleString()}
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="text-gray-500">No headlines available. Please collect news first.</div>
            )}
            <div className="mt-4">
              <a href="/headlines" className="text-blue-600 hover:text-blue-800">
                View all headlines →
              </a>
            </div>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-2xl font-semibold mb-4">Top Writers' Articles</h2>
            <p className="mb-4">
              Read the latest articles from Israel's most prominent journalists and writers.
            </p>
            <div className="mt-4">
              <a href="/articles" className="text-blue-600 hover:text-blue-800">
                View articles by top writers →
              </a>
            </div>
          </div>
        </div>
        
        <div className="mt-8 bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-2xl font-semibold mb-4">About This Project</h2>
          <p className="mb-4">
            This web application collects news headlines from major Israeli news websites and articles by top writers.
            The data is updated regularly to provide you with the latest news from Israel.
          </p>
          <p className="mb-4">
            Sources include Ynet, Haaretz, Jerusalem Post, Israel Hayom, and Walla.
          </p>
          <div className="mt-4">
            <a href="/about" className="text-blue-600 hover:text-blue-800">
              Learn more about this project →
            </a>
          </div>
        </div>
      </div>
    </main>
  );
}
