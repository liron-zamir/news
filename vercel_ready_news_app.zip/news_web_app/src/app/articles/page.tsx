import { getRecentArticlesByTopWriters } from '@/lib/news-collector';

export const dynamic = 'force-dynamic';

export default async function Articles() {
  // Get the database binding
  // Using Vercel Postgres directly in the functions
  
  // Fetch recent articles by top writers
  let articles = [];
  let error = null;
  
  try {
    if (db) {
      articles = await getRecentArticlesByTopWriters(50);
    } else {
      error = "Database not available";
    }
  } catch (e) {
    error = e instanceof Error ? e.message : "Unknown error";
  }
  
  return (
    <main className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Articles by Top Writers</h1>
        
        <div className="mb-6">
          <a href="/" className="text-blue-600 hover:text-blue-800">
            ← Back to home
          </a>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          {error ? (
            <div className="text-red-500">{error}</div>
          ) : articles.length > 0 ? (
            <div>
              <div className="mb-4 text-sm text-gray-500">
                Showing {articles.length} articles by top Israeli writers
              </div>
              
              <ul className="space-y-6 divide-y">
                {articles.map((article: any) => (
                  <li key={article.id} className="pt-6">
                    <a 
                      href={article.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:text-blue-800 font-medium text-lg"
                    >
                      {article.title}
                    </a>
                    <div className="text-sm text-gray-500 mt-1">
                      Writer: <span className="font-medium">{article.writer}</span> | 
                      Source: {article.source} | 
                      Language: {article.language} | 
                      Collected: {new Date(article.collected_at).toLocaleString()}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          ) : (
            <div className="text-gray-500 py-8 text-center">
              <p className="mb-4">No articles by top writers available yet.</p>
              <p>Articles will appear here after the news collection process runs.</p>
            </div>
          )}
        </div>
      </div>
    </main>
  );
}
