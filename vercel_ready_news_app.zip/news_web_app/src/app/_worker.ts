// This file contains the scheduled cron job for news collection
import { collectAllNews } from '@/lib/news-collector';

export async function scheduled(event: ScheduledEvent, env: any, ctx: ExecutionContext) {
  console.log("Running scheduled news collection job");
  
  try {
    // Get the database binding
    const db = env.DB;
    
    if (!db) {
      console.error("Database not available");
      return;
    }
    
    // Collect news from all websites
    const result = await collectAllNews(db);
    
    console.log(`Collected ${result.headlines} headlines and ${result.articles} articles`);
  } catch (error) {
    console.error("Error in scheduled job:", error);
  }
}
