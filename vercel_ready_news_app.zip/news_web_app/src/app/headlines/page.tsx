import { getRecentHeadlines } from '@/lib/news-collector';

export const dynamic = 'force-dynamic';

export default async function Headlines() {
  // Get the database binding
  // Using Vercel Postgres directly in the functions
  
  // Fetch recent headlines
  let headlines = [];
  let error = null;
  
  try {
    if (db) {
      headlines = await getRecentHeadlines(50);
    } else {
      error = "Database not available";
    }
  } catch (e) {
    error = e instanceof Error ? e.message : "Unknown error";
  }
  
  return (
    <main className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Latest Headlines</h1>
        
        <div className="mb-6">
          <a href="/" className="text-blue-600 hover:text-blue-800">
            ← Back to home
          </a>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md">
          {error ? (
            <div className="text-red-500">{error}</div>
          ) : headlines.length > 0 ? (
            <div>
              <div className="mb-4 text-sm text-gray-500">
                Showing {headlines.length} headlines
              </div>
              
              <ul className="space-y-4 divide-y">
                {headlines.map((headline: any) => (
                  <li key={headline.id} className="pt-4">
                    <a 
                      href={headline.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:text-blue-800 font-medium text-lg"
                    >
                      {headline.title}
                    </a>
                    <div className="text-sm text-gray-500 mt-1">
                      Source: <span className="font-medium">{headline.source}</span> | 
                      Language: {headline.language} | 
                      Collected: {new Date(headline.collected_at).toLocaleString()}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          ) : (
            <div className="text-gray-500 py-8 text-center">
              <p className="mb-4">No headlines available yet.</p>
              <p>Headlines will appear here after the news collection process runs.</p>
            </div>
          )}
        </div>
      </div>
    </main>
  );
}
